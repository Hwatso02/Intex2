﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Intex2.Models
{
    public partial class BodyAnalysisChart
    {
        public long Id { get; set; }
        public string Femur { get; set; }
        public string Humerusheaddiameter { get; set; }
        public string Squamossuture { get; set; }
        public string CariesPeriodontalDisease { get; set; }
        public string MedicalIpRamus { get; set; }
        public int? Perservationindex { get; set; }
        public string Gonion { get; set; }
        public int? Humeruslength { get; set; }
        public int? Femurlength { get; set; }
        public string Lambdoidsuture { get; set; }
        public bool? Ventralarc { get; set; }
        public int? Tootheruptionageestimation { get; set; }
        public string Nuchalcrest { get; set; }
        public int? Estimatestature { get; set; }
        public string Notes { get; set; }
        public string Osteophytosis { get; set; }
        public string Subpubicangle { get; set; }
        public bool? Robust { get; set; }
        public string Femurheaddiameter { get; set; }
        public string Sciaticnotch { get; set; }
        public string Supraorbitalridges { get; set; }
        public string Orbitedge { get; set; }
        public int? Toothattrition { get; set; }
        public string Sphenooccipitalsynchondrosis { get; set; }
        public bool? Parietalblossing { get; set; }
        public string Observations { get; set; }
        public string Humerus { get; set; }
    }
}
