﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intex2.Models.ViewModels
{
    public class BurialsViewModel
    {
        public List<BurialMain> Burialmains { get; set; }
        public List<BodyAnalysisChart> Bodyanalysischarts { get; set; }

    }
}
